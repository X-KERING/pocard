class MethodNotFound(Exception):
    pass